
import React, { useEffect } from 'react';
import { RecoilRoot, useRecoilState } from 'recoil';
import { CssBaseline, Button } from '@mui/material';
import AdminView from './components/AdminView';
import UserView from './components/UserView';
import { fetchInventory } from './api';
import { productListState, userRoleState } from './recoil/atoms';

function App() {
  const [userRole, setUserRole] = useRecoilState(userRoleState);
  const [products, setProducts] = useRecoilState(productListState);

  useEffect(() => {
    fetchInventory().then(data => setProducts(data));
  }, [setProducts]);

  const toggleRole = () => {
    setUserRole(userRole === 'admin' ? 'user' : 'admin');
  };

  return (
    <RecoilRoot>
      <CssBaseline />
      <div style={{ padding: 20 }}>
        <Button variant="contained" onClick={toggleRole}>
          Switch to {userRole === 'admin' ? 'User' : 'Admin'} View
        </Button>
        {userRole === 'admin' ? <AdminView /> : <UserView />}
      </div>
    </RecoilRoot>
  );
}

export default App;
            