
import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableRow, IconButton } from '@mui/material';
import { useRecoilValue } from 'recoil';
import { productListState, userRoleState } from '../recoil/atoms';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';

const ProductTable = ({ onEdit, onDelete, onDisable }) => {
  const productList = useRecoilValue(productListState);
  const userRole = useRecoilValue(userRoleState);

  return (
    <Table>
      <TableHead>
        <TableRow>
          <TableCell>Product Name</TableCell>
          <TableCell>Price</TableCell>
          <TableCell>Quantity</TableCell>
          <TableCell>Actions</TableCell>
        </TableRow>
      </TableHead>
      <TableBody>
        {productList.map((product) => (
          <TableRow key={product.id}>
            <TableCell>{product.name}</TableCell>
            <TableCell>{product.price}</TableCell>
            <TableCell>{product.quantity}</TableCell>
            <TableCell>
              {userRole === 'admin' && (
                <>
                  <IconButton onClick={() => onEdit(product)}><EditIcon /></IconButton>
                  <IconButton onClick={() => onDelete(product.id)}><DeleteIcon /></IconButton>
                  <IconButton onClick={() => onDisable(product.id)}><VisibilityOffIcon /></IconButton>
                </>
              )}
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
};

export default ProductTable;
                