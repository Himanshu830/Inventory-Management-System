
import React from 'react';
import ProductTable from './ProductTable';

const UserView = () => {
  return <ProductTable />;
};

export default UserView;
                