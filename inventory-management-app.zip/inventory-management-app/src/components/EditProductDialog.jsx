
import React, { useState } from 'react';
import { Dialog, DialogActions, DialogContent, DialogTitle, Button, TextField } from '@mui/material';

const EditProductDialog = ({ product, onClose, onSave }) => {
  const [updatedProduct, setUpdatedProduct] = useState(product);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUpdatedProduct({ ...updatedProduct, [name]: value });
  };

  return (
    <Dialog open={true} onClose={onClose}>
      <DialogTitle>Edit Product</DialogTitle>
      <DialogContent>
        <TextField
          label="Product Name"
          name="name"
          value={updatedProduct.name}
          onChange={handleChange}
          fullWidth
          margin="dense"
        />
        <TextField
          label="Price"
          name="price"
          value={updatedProduct.price}
          onChange={handleChange}
          fullWidth
          margin="dense"
        />
        <TextField
          label="Quantity"
          name="quantity"
          value={updatedProduct.quantity}
          onChange={handleChange}
          fullWidth
          margin="dense"
        />
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={() => onSave(updatedProduct)}>Save</Button>
      </DialogActions>
    </Dialog>
  );
};

export default EditProductDialog;
                